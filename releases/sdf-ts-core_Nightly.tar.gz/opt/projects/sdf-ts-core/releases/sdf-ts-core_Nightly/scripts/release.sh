#!/bin/bash
set -e

echo 'release script for sdf-ts-core'

cd /opt/projects/sdf-ts-core
cp changelog releases/latest
mkdir -p releases/latest/scripts
cp scripts/* releases/latest/scripts
